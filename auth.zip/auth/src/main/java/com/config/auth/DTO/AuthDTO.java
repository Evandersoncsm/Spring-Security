package com.config.auth.DTO;

public record AuthDTO(
        String login,
        String password
) {
}
