package com.config.auth.entities;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

public enum UserRole {

    ADMIN("ROLE_ADMIN"),
    USER("ROLE_USER");

    private final String role;

    UserRole(String role) {
        this.role = role;
    }

    public String getRole() {
        return role;
    }

    public GrantedAuthority getAuthority() {
        return new SimpleGrantedAuthority(this.role);
    }

    @Override
    public String toString() {
        return this.role;
    }
}
