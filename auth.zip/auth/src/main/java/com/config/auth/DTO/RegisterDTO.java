package com.config.auth.DTO;

public record RegisterDTO(
        String login,
        String password,
        String role
) {
}
