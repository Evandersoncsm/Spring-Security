package com.config.auth.controller;

import com.config.auth.DTO.AuthDTO;
import com.config.auth.DTO.AuthResponseDTO;
import com.config.auth.DTO.RegisterDTO;
import com.config.auth.entities.User;
import com.config.auth.entities.UserRole;
import com.config.auth.repository.UserRepository;
import com.config.auth.security.TokenService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final TokenService tokenService;

    public AuthController(AuthenticationManager authenticationManager,
                          UserRepository userRepository,
                          PasswordEncoder passwordEncoder,
                          TokenService tokenService) {
        this.authenticationManager = authenticationManager;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.tokenService = tokenService;
    }

    @PostMapping("/register/user")
    public ResponseEntity<?> registerUser(@RequestBody @Validated RegisterDTO data) {
        Optional<User> existingUser = userRepository.findByLogin(data.login());
        if (existingUser.isPresent()) {
            return ResponseEntity.badRequest().body("Usuário com este login já existe.");
        }

        String encryptedPassword = passwordEncoder.encode(data.password());
        User newUser = new User(data.login(), encryptedPassword, UserRole.USER);
        userRepository.save(newUser);

        return ResponseEntity.ok("Usuário registrado com sucesso como USER.");
    }

    @PostMapping("/register/admin")
    public ResponseEntity<?> registerAdmin(@RequestBody @Validated RegisterDTO data) {
        Optional<User> existingUser = userRepository.findByLogin(data.login());
        if (existingUser.isPresent()) {
            return ResponseEntity.badRequest().body("Usuário com este login já existe.");
        }

        String encryptedPassword = passwordEncoder.encode(data.password());
        User newUser = new User(data.login(), encryptedPassword, UserRole.ADMIN);
        userRepository.save(newUser);

        return ResponseEntity.ok("Usuário registrado com sucesso como ADMIN.");
    }

    @PostMapping("/login/user")
    public ResponseEntity<?> loginUser(@RequestBody @Validated AuthDTO data) {
        try {
            Authentication auth = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(data.login(), data.password())
            );
            SecurityContextHolder.getContext().setAuthentication(auth);

            boolean isUserRole = auth.getAuthorities().stream()
                    .map(GrantedAuthority::getAuthority)
                    .collect(Collectors.toSet())
                    .contains("ROLE_USER");

            if (isUserRole) {
                User user = (User) auth.getPrincipal();
                String token = tokenService.generateToken(user);
                AuthResponseDTO response = new AuthResponseDTO(token);
                return ResponseEntity.ok(response);
            } else {
                return ResponseEntity.status(403).body("Acesso negado. O login requer o papel de USER.");
            }
        } catch (Exception e) {
            return ResponseEntity.status(401).body("Falha na autenticação do usuário: " + e.getMessage());
        }
    }

    @PostMapping("/login/admin")
    public ResponseEntity<?> loginAdmin(@RequestBody @Validated AuthDTO data) {
        try {
            Authentication auth = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(data.login(), data.password())
            );
            SecurityContextHolder.getContext().setAuthentication(auth);

            boolean isAdminRole = auth.getAuthorities().stream()
                    .map(GrantedAuthority::getAuthority)
                    .collect(Collectors.toSet())
                    .contains("ROLE_ADMIN");

            if (isAdminRole) {
                User user = (User) auth.getPrincipal();
                String token = tokenService.generateToken(user);
                AuthResponseDTO response = new AuthResponseDTO(token);
                return ResponseEntity.ok(response);
            } else {
                return ResponseEntity.status(403).body("Acesso negado. O login requer o papel de ADMIN.");
            }
        } catch (Exception e) {
            return ResponseEntity.status(401).body("Falha na autenticação do admin: " + e.getMessage());
        }
    }
}
